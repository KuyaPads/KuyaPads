
import React from 'react';
import { motion } from 'framer-motion';
import { Coins, TrendingUp } from 'lucide-react';

const EarningsWidget = ({ kpcBalance, totalEarnings }) => {
  const balance = kpcBalance ?? 0;
  const earnings = totalEarnings ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      className="earnings-widget floating-kpc"
    >
      <div className="flex items-center space-x-3">
        <Coins className="w-5 h-5" />
        <div className="text-sm">
          <div className="font-semibold">{balance.toFixed(2)} KPC</div>
          <div className="text-xs opacity-80 flex items-center">
            <TrendingUp className="w-3 h-3 mr-1" />
            Total: {earnings.toFixed(2)}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default EarningsWidget;
