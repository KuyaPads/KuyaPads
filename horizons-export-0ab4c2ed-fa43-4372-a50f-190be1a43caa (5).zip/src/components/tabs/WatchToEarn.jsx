import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { PlayCircle, Clock, DollarSign, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const WatchToEarn = ({ user, addEarnings }) => {
  const [videos, setVideos] = useState([]);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dailyCap, setDailyCap] = useState(50);
  const [earnedToday, setEarnedToday] = useState(0);
  const { toast } = useToast();

  const fetchVideos = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('videos').select('*');
    if (error) {
      console.error('Error fetching videos:', error);
      toast({ title: "Error fetching videos", variant: "destructive" });
    } else {
      setVideos(data);
      if (data.length > 0) {
        setSelectedVideo(data[0]);
      }
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchVideos();
  }, [fetchVideos]);

  const handleWatchVideo = (video) => {
    if (!user) {
      toast({ title: "Please log in to earn rewards.", variant: "destructive" });
      return;
    }
    if (earnedToday + video.reward > dailyCap) {
      toast({
        title: "Daily Cap Reached",
        description: `You've reached your daily earning limit of ${dailyCap} KPC from watching videos.`,
        variant: "destructive"
      });
      return;
    }
    
    addEarnings(video.reward, 'Watching Video');
    setEarnedToday(prev => prev + video.reward);
    setSelectedVideo(video);
    toast({
      title: `🎉 You earned ${video.reward} KPC!`,
      description: `For watching "${video.title}"`,
    });
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-white mb-4">Watch-to-Earn</h1>
          <p className="text-xl text-white/70 mb-6">
            Watch videos, discover content, and earn KPC rewards
          </p>
          <div className="kuyapads-card max-w-md mx-auto p-4">
            <h3 className="text-lg font-semibold text-white">Daily Earnings</h3>
            <div className="w-full bg-white/10 rounded-full h-4 mt-2">
              <div
                className="bg-gradient-to-r from-green-400 to-blue-500 h-4 rounded-full"
                style={{ width: `${(earnedToday / dailyCap) * 100}%` }}
              ></div>
            </div>
            <p className="text-white/70 mt-2">
              {earnedToday.toFixed(2)} / {dailyCap} KPC
            </p>
          </div>
        </motion.div>

        {loading ? <p className="text-white text-center">Loading videos...</p> : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="kuyapads-card p-6"
              >
                <div className="aspect-video bg-white/5 rounded-lg flex items-center justify-center mb-4">
                  {selectedVideo ? (
                    <img src={selectedVideo.thumbnail_url} alt={selectedVideo.title} className="w-full h-full object-cover rounded-lg" />
                  ) : (
                    <div className="text-center">
                      <PlayCircle className="w-24 h-24 text-white/40 mx-auto mb-4" />
                      <p className="text-white/60">Select a video to start earning</p>
                    </div>
                  )}
                </div>
                {selectedVideo && (
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-2">{selectedVideo.title}</h2>
                    <div className="flex items-center space-x-4 text-white/70">
                      <div className="flex items-center space-x-1">
                        <Eye className="w-4 h-4" />
                        <span>{selectedVideo.views_count} views</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{selectedVideo.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1 text-yellow-400">
                        <DollarSign className="w-4 h-4" />
                        <span className="font-semibold">Reward: {selectedVideo.reward} KPC</span>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>

            <div className="lg:col-span-1">
              <div className="kuyapads-card p-4 max-h-[600px] overflow-y-auto">
                <h3 className="text-xl font-semibold text-white mb-4 p-2">Up Next</h3>
                <div className="space-y-4">
                  {videos.map((video, index) => (
                    <motion.div
                      key={video.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`p-3 rounded-lg cursor-pointer transition-all ${
                        selectedVideo?.id === video.id
                          ? 'bg-yellow-400/20'
                          : 'hover:bg-white/10'
                      }`}
                      onClick={() => handleWatchVideo(video)}
                    >
                      <div className="flex items-start space-x-4">
                        <div className="relative flex-shrink-0">
                          <img 
                            className="w-32 h-20 object-cover rounded-lg"
                            src={video.thumbnail_url}
                            alt={video.title} />
                          <div className="absolute bottom-1 right-1 bg-black/70 text-white text-xs px-1 rounded">
                            {video.duration}
                          </div>
                        </div>
                        <div>
                          <h4 className="text-white font-semibold leading-tight mb-1">{video.title}</h4>
                          <div className="flex items-center space-x-2 text-sm text-yellow-400">
                            <DollarSign className="w-3 h-3" />
                            <span>{video.reward} KPC</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WatchToEarn;