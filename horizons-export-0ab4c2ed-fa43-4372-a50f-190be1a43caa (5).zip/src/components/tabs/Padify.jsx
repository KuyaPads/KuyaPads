import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Music, Mic, Play, Pause, SkipForward, SkipBack, Heart, Plus, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Padify = ({ user, addEarnings }) => {
  const [activeTab, setActiveTab] = useState('music');
  const [tracks, setTracks] = useState([]);
  const [podcasts, setPodcasts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(null);
  const { toast } = useToast();

  const fetchAudio = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('audio_tracks').select('*');
    if (error) {
      console.error('Error fetching audio:', error);
      toast({ title: "Error fetching audio", variant: "destructive" });
    } else {
      setTracks(data.filter(t => t.type === 'music'));
      setPodcasts(data.filter(t => t.type === 'podcast'));
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchAudio();
  }, [fetchAudio]);

  const handlePlay = (track) => {
    if (!user) {
      toast({ title: "Please log in to play audio.", variant: "destructive" });
      return;
    }
    setCurrentTrack(track);
    setIsPlaying(true);
    addEarnings(0.1, 'Streaming on Padify');
    toast({
      title: `Now Playing: ${track.title}`,
      description: `by ${track.artist || track.host || 'Unknown Artist'}`,
    });
  };

  const handleTogglePlay = () => {
    if (currentTrack) {
      setIsPlaying(!isPlaying);
    }
  };

  const handleUpload = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const contentList = activeTab === 'music' ? tracks : podcasts;

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Padify</h1>
          <p className="text-white/70">Stream, publish, and monetize your audio content</p>
        </motion.div>

        <div className="flex items-center justify-between mb-8">
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveTab('music')}
              className={`kuyapads-tab flex items-center space-x-2 ${
                activeTab === 'music' ? 'active' : ''
              }`}
            >
              <Music className="w-4 h-4" />
              <span>Music</span>
            </button>
            <button
              onClick={() => setActiveTab('podcasts')}
              className={`kuyapads-tab flex items-center space-x-2 ${
                activeTab === 'podcasts' ? 'active' : ''
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>Podcasts</span>
            </button>
          </div>
          <Button
            onClick={handleUpload}
            className="kuyapads-button"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Content
          </Button>
        </div>

        {loading ? <p className="text-white text-center">Loading content...</p> : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contentList.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="kuyapads-card p-4 group"
              >
                <div className="relative mb-4">
                  <img 
                    className="w-full h-48 object-cover rounded-lg"
                    src={item.image_url || "https://images.unsplash.com/photo-1511379938547-c1f69419868d"}
                    alt={item.title} />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handlePlay(item)}
                      className="w-16 h-16 bg-yellow-400/80 rounded-full flex items-center justify-center text-black hover:bg-yellow-400"
                    >
                      <Play className="w-8 h-8" />
                    </button>
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold text-white truncate">{item.title}</h3>
                <p className="text-white/70 truncate">{item.artist || item.host || 'Unknown Artist'}</p>
              </motion.div>
            ))}
          </div>
        )}

        {currentTrack && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="fixed bottom-0 left-0 right-0 z-50"
          >
            <div className="bg-slate-900/80 backdrop-blur-lg border-t border-white/10 p-4">
              <div className="max-w-7xl mx-auto flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <img 
                    className="w-16 h-16 object-cover rounded-lg"
                    src={currentTrack.image_url || "https://images.unsplash.com/photo-1511379938547-c1f69419868d"}
                    alt={currentTrack.title} />
                  <div>
                    <h3 className="text-lg font-semibold text-white">{currentTrack.title}</h3>
                    <p className="text-white/70">{currentTrack.artist || currentTrack.host || 'Unknown Artist'}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-6">
                  <button className="text-white/70 hover:text-white">
                    <SkipBack className="w-6 h-6" />
                  </button>
                  <button
                    onClick={handleTogglePlay}
                    className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center text-black"
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                  </button>
                  <button className="text-white/70 hover:text-white">
                    <SkipForward className="w-6 h-6" />
                  </button>
                </div>
                
                <div className="flex items-center space-x-4">
                  <button className={`text-white/70 hover:text-white`}>
                    <Heart className="w-6 h-6" />
                  </button>
                  <button className="text-white/70 hover:text-white">
                    <Plus className="w-6 h-6" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Padify;