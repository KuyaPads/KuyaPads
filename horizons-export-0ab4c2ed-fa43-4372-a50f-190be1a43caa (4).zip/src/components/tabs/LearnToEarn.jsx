import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, DollarSign, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const LearnToEarn = ({ user, addEarnings }) => {
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchCourses = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('courses').select('*');
    if (error) {
      console.error('Error fetching courses:', error);
      toast({ title: "Error fetching courses", variant: "destructive" });
    } else {
      setCourses(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  const handleCompleteCourse = (course) => {
    if (!user) {
      toast({ title: "Please log in to complete a course.", variant: "destructive" });
      return;
    }
    addEarnings(course.reward, `Completing ${course.title}`);
    toast({
      title: "🎉 Course Completed!",
      description: `You've earned ${course.reward} KPC and a certificate for completing "${course.title}".`,
    });
    setSelectedCourse(null);
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-white mb-4">Learn-to-Earn</h1>
          <p className="text-xl text-white/70">
            Learn valuable skills, complete courses, and earn KPC rewards
          </p>
        </motion.div>

        {!selectedCourse ? (
          loading ? <p className="text-white text-center">Loading courses...</p> : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {courses.map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="kuyapads-card p-6 hover:scale-105 transition-transform duration-300 cursor-pointer"
                  onClick={() => setSelectedCourse(course)}
                >
                  <div className="mb-4">
                    <img 
                      className="w-full h-40 object-cover rounded-lg"
                      src={course.image_url || "https://images.unsplash.com/photo-1503676260728-1c00da094a0b"}
                      alt={course.title} />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-white mb-3">{course.title}</h3>
                  
                  <div className="flex items-center justify-between text-white/70 mb-4">
                    <span>{course.modules_count} modules</span>
                    <span>{course.duration}</span>
                  </div>
                  
                  <div className="flex items-center justify-between bg-yellow-400/10 p-3 rounded-lg">
                    <span className="text-yellow-400 font-semibold">Reward</span>
                    <span className="text-yellow-400 font-bold">{course.reward} KPC</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="kuyapads-card p-8"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">{selectedCourse.title}</h2>
              <Button
                onClick={() => setSelectedCourse(null)}
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10"
              >
                Back to Courses
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <div className="aspect-video bg-white/5 rounded-lg flex items-center justify-center mb-6">
                  <div className="text-center">
                    <BookOpen className="w-16 h-16 text-white/40 mx-auto mb-4" />
                    <p className="text-white/60">Course Content Placeholder</p>
                    <p className="text-white/40 text-sm">Video lessons and quizzes will appear here</p>
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-white mb-4">Course Modules</h3>
                <div className="space-y-3">
                  {[...Array(selectedCourse.modules_count || 5)].map((_, i) => (
                    <div key={i} className="flex items-center space-x-3 p-4 bg-white/5 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-400" />
                      <span className="text-white">Module {i + 1}: Introduction to Topic</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold text-white mb-4">Course Details</h3>
                <div className="space-y-4 mb-6">
                  <div className="flex items-center space-x-3">
                    <DollarSign className="w-5 h-5 text-yellow-400" />
                    <span className="text-white">Reward: {selectedCourse.reward} KPC</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Award className="w-5 h-5 text-blue-400" />
                    <span className="text-white">Certificate of Completion</span>
                  </div>
                </div>
                
                <Button
                  onClick={() => handleCompleteCourse(selectedCourse)}
                  className="w-full kuyapads-button"
                >
                  Complete Course & Claim Reward
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default LearnToEarn;