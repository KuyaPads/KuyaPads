
import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const mainLinks = [
    { label: 'Home', path: '/' },
    { label: 'Social', path: '/social' },
    { label: 'Wallet', path: '/wallet' },
    { label: 'Booking', path: '/booking' },
    { label: 'Trading', path: '/trading' },
    { label: 'Studio', path: '/studio' },
    { label: 'Shop', path: '/shop' },
    { label: 'Agency', path: '/agency' },
    { label: 'Cloud', path: '/cloud' },
    { label: 'Padify', path: '/padify' },
    { label: 'KuyaMind', path: '/kuyamind' },
    { label: 'Learn-to-Earn', path: '/learn-to-earn' },
    { label: 'Watch-to-Earn', path: '/watch-to-earn' },
    { label: 'Support', path: '/support' },
  ];

  const legalLinks = [
    { label: 'Privacy', path: '/privacy' },
    { label: 'Terms', path: '/terms' },
    { label: 'Policy', path: '/policy' },
    { label: 'Cookies', path: '/cookies' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  return (
    <footer className="bg-slate-900/50 border-t border-white/10 mt-16">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center space-x-2">
              <img src="https://horizons-cdn.hostinger.com/0ab4c2ed-fa43-4372-a50f-190be1a43caa/bfb567a0fadd3636d597c2c5f18977b5.png" alt="KuyaPads Network Logo" className="h-12 w-auto" />
            </Link>
            <p className="mt-4 text-white/60 text-sm">
              Create • Earn • Explore — All in KuyaPads.
            </p>
          </div>

          <div>
            <p className="font-semibold text-white">Platform</p>
            <ul className="mt-4 space-y-2">
              {mainLinks.slice(1, 7).map(link => (
                <li key={link.path}>
                  <Link to={link.path} className="text-white/60 hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-semibold text-white">Resources</p>
            <ul className="mt-4 space-y-2">
              {mainLinks.slice(7, 13).map(link => (
                <li key={link.path}>
                  <Link to={link.path} className="text-white/60 hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-semibold text-white">Company</p>
            <ul className="mt-4 space-y-2">
              {legalLinks.map(link => (
                <li key={link.path}>
                  <Link to={link.path} className="text-white/60 hover:text-white transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-8 text-center text-white/60 text-sm">
          <p>&copy; {new Date().getFullYear()} KuyaPads Network. All rights reserved. From The Happy Island to the world.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
