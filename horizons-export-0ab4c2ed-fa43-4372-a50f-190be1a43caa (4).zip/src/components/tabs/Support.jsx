import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { HelpCircle, BookOpen, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Support = ({ user }) => {
  const [activeTab, setActiveTab] = useState('faq');
  const { toast } = useToast();

  const faqs = [
    { q: 'What is KuyaPads Coin (KPC)?', a: 'KPC is the native BEP-20 token that powers the KuyaPads Network. It is used for all transactions, rewards, and fees within the ecosystem.' },
    { q: 'How do I earn KPC?', a: 'You can earn KPC through various activities like social media engagement, completing courses, watching videos, referrals, and selling products or services.' },
    { q: 'Is my money safe in the KuyaPads Wallet?', a: 'Yes, we prioritize security with features like 2FA and KYC compliance. However, always practice good security habits.' },
    { q: 'What are the fees on the platform?', a: 'There is a universal 2% service fee on most transactions. Specific features have their own commission structures. Please refer to our detailed Fees page.' }
  ];

  const handleSubmitTicket = async (e) => {
    e.preventDefault();
    if (!user) {
        toast({ title: "You must be logged in to submit a ticket.", variant: "destructive" });
        return;
    }
    const formData = new FormData(e.target);
    const ticketData = Object.fromEntries(formData.entries());

    const { error } = await supabase.from('support_tickets').insert({
        user_id: user.id,
        email: ticketData.email,
        subject: ticketData.subject,
        body: ticketData.body,
        status: 'open'
    });

    if (error) {
        toast({ title: "Failed to submit ticket", description: error.message, variant: "destructive" });
    } else {
        toast({ title: "Ticket Submitted", description: "Our team will get back to you within 24 hours." });
        e.target.reset();
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Support Center</h1>
          <p className="text-xl text-white/70 mb-6">How can we help you today?</p>
        </motion.div>

        <div className="flex space-x-4 mb-8 justify-center">
          {[
            { id: 'faq', label: 'FAQ', icon: HelpCircle },
            { id: 'ticket', label: 'Submit Ticket', icon: Send },
            { id: 'policies', label: 'Policies', icon: BookOpen }
          ].map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`kuyapads-tab flex items-center space-x-2 ${activeTab === tab.id ? 'active' : ''}`}>
              <tab.icon className="w-4 h-4" /><span>{tab.label}</span>
            </button>
          ))}
        </div>

        {activeTab === 'faq' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="kuyapads-card p-6">
                <h3 className="text-lg font-semibold text-white mb-2">{faq.q}</h3>
                <p className="text-white/80">{faq.a}</p>
              </div>
            ))}
          </motion.div>
        )}

        {activeTab === 'ticket' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="kuyapads-card p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Submit a Support Ticket</h2>
            <form onSubmit={handleSubmitTicket} className="space-y-6">
              <div>
                <label className="block text-white/70 text-sm mb-2">Your Email</label>
                <input type="email" name="email" defaultValue={user?.email || ''} required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:border-yellow-400" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-2">Subject</label>
                <input type="text" name="subject" placeholder="e.g. Issue with KPC withdrawal" required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:border-yellow-400" />
              </div>
              <div>
                <label className="block text-white/70 text-sm mb-2">Describe your issue</label>
                <textarea name="body" rows={6} placeholder="Please provide as much detail as possible..." required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 resize-none focus:outline-none focus:border-yellow-400" />
              </div>
              <Button type="submit" className="w-full kuyapads-button">Submit Ticket</Button>
            </form>
          </motion.div>
        )}
        
        {activeTab === 'policies' && (
            <div className="kuyapads-card p-8 text-center">
                <BookOpen className="w-16 h-16 text-blue-400 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-white mb-4">Policies Coming Soon</h3>
                <p className="text-white/70">Our Terms of Service, Privacy Policy, and other documents will be available here.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Support;