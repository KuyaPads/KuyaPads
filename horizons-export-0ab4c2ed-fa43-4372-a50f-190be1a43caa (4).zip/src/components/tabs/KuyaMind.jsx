import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { BrainCircuit, DollarSign, Briefcase, BookOpen, HeartPulse, Send, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const KuyaMind = ({ user, addEarnings }) => {
  const [advisors, setAdvisors] = useState([]);
  const [selectedAdvisor, setSelectedAdvisor] = useState(null);
  const [chatHistory, setChatHistory] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const advisorIcons = {
    'Financial Advisor': DollarSign,
    'Business Coach': Briefcase,
    'Learning Mentor': BookOpen,
    'Wellness Guide': HeartPulse,
  };

  const fetchAdvisors = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('ai_advisors').select('*');
    if (error) {
      console.error('Error fetching advisors:', error);
      toast({ title: "Error fetching advisors", variant: "destructive" });
    } else {
      setAdvisors(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchAdvisors();
  }, [fetchAdvisors]);

  const handleSendMessage = () => {
    if (!input.trim()) return;

    const userMessage = { sender: 'user', text: input };
    const advisorResponse = { sender: 'advisor', text: `This is a simulated response from the ${selectedAdvisor.name}. Real AI integration is coming soon!` };

    setChatHistory([...chatHistory, userMessage, advisorResponse]);
    setInput('');
    addEarnings(1, 'Using KuyaMind AI');
  };

  const handleSubscribe = () => {
    if (!user) {
      toast({ title: "Please log in to subscribe.", variant: "destructive" });
      return;
    }
    addEarnings(10, 'KuyaMind Subscription');
    toast({
      title: "🎉 Subscribed to KuyaMind!",
      description: "You now have full access to all AI Pro Advisors for ₱499 KPC/month.",
    });
  };

  const handleNotImplemented = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const getAdvisorIcon = (name) => advisorIcons[name] || BrainCircuit;

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-white mb-4">KuyaMind AI Pro Advisors</h1>
          <p className="text-xl text-white/70 mb-6">
            Your personal AI council for finance, business, education, and health
          </p>
          <Button
            onClick={handleSubscribe}
            className="kuyapads-button"
          >
            Subscribe Now (₱499 KPC/month)
          </Button>
        </motion.div>

        {!selectedAdvisor ? (
          loading ? <p className="text-white text-center">Loading advisors...</p> : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {advisors.map((advisor, index) => {
                const Icon = getAdvisorIcon(advisor.name);
                return (
                  <motion.div
                    key={advisor.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="kuyapads-card p-6 hover:scale-105 transition-transform duration-300 cursor-pointer"
                    onClick={() => {
                      setSelectedAdvisor(advisor);
                      setChatHistory([{ sender: 'advisor', text: `Hello! I am your ${advisor.name}. How can I assist you today?` }]);
                    }}
                  >
                    <div className={`w-16 h-16 bg-gradient-to-r ${advisor.color_from} ${advisor.color_to} rounded-lg flex items-center justify-center mb-4`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">{advisor.name}</h3>
                    <p className="text-white/70">{advisor.description}</p>
                  </motion.div>
                );
              })}
            </div>
          )
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="kuyapads-card"
          >
            <div className="p-6 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 bg-gradient-to-r ${selectedAdvisor.color_from} ${selectedAdvisor.color_to} rounded-full flex items-center justify-center`}>
                  {React.createElement(getAdvisorIcon(selectedAdvisor.name), { className: "w-6 h-6 text-white" })}
                </div>
                <h2 className="text-xl font-bold text-white">{selectedAdvisor.name}</h2>
              </div>
              <Button
                onClick={() => setSelectedAdvisor(null)}
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10"
              >
                Back
              </Button>
            </div>

            <div className="p-6 h-96 overflow-y-auto space-y-4">
              {chatHistory.map((message, index) => {
                const Icon = getAdvisorIcon(selectedAdvisor.name);
                return (
                  <div
                    key={index}
                    className={`flex items-start gap-3 ${
                      message.sender === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {message.sender === 'advisor' && (
                      <div className={`w-8 h-8 bg-gradient-to-r ${selectedAdvisor.color_from} ${selectedAdvisor.color_to} rounded-full flex items-center justify-center flex-shrink-0`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-md p-4 rounded-2xl ${
                        message.sender === 'user'
                          ? 'bg-blue-600 text-white rounded-br-none'
                          : 'bg-white/10 text-white rounded-bl-none'
                      }`}
                    >
                      {message.text}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-6 border-t border-white/10">
              <div className="flex items-center space-x-4">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask your advisor..."
                  className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:border-yellow-400"
                />
                <Button
                  onClick={handleSendMessage}
                  className="kuyapads-button"
                >
                  <Send className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleNotImplemented}
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default KuyaMind;