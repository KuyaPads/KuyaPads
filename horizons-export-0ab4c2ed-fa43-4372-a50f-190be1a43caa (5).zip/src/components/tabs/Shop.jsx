import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ShoppingBag, Package, Download, Star, Filter, Search, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Shop = ({ user, addEarnings }) => {
  const [activeMarket, setActiveMarket] = useState('digital');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { toast } = useToast();

  const categories = ['all', 'Design', 'Education', 'Business', 'Photography', 'Apparel', 'Food', 'Crafts'];

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    let query = supabase.from('products').select('*').eq('type', activeMarket);

    if (searchTerm) {
      query = query.ilike('title', `%${searchTerm}%`);
    }
    if (selectedCategory !== 'all') {
      query = query.eq('category', selectedCategory);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching products:', error);
      toast({ title: "Error fetching products", variant: "destructive" });
    } else {
      setProducts(data);
    }
    setLoading(false);
  }, [activeMarket, searchTerm, selectedCategory, toast]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const handlePurchase = (product) => {
    const platformFee = product.price * (product.commission_pct / 100);
    addEarnings(Math.floor(platformFee * 0.1), 'Shop Purchase Commission');
    toast({
      title: "🎉 Purchase Successful!",
      description: `${product.title} purchased for ₱${product.price.toLocaleString()}.`,
    });
  };

  const handleSellProduct = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">One Stop Shop</h1>
          <p className="text-white/70">Global marketplace for digital and physical products</p>
        </motion.div>

        <div className="flex items-center justify-between mb-8">
          <div className="flex space-x-4">
            <button onClick={() => setActiveMarket('digital')} className={`kuyapads-tab flex items-center space-x-2 ${activeMarket === 'digital' ? 'active' : ''}`}>
              <Download className="w-4 h-4" /><span>Digital Market</span><span className="text-xs bg-white/20 px-2 py-1 rounded-full">30% fee</span>
            </button>
            <button onClick={() => setActiveMarket('physical')} className={`kuyapads-tab flex items-center space-x-2 ${activeMarket === 'physical' ? 'active' : ''}`}>
              <Package className="w-4 h-4" /><span>Physical Market</span><span className="text-xs bg-white/20 px-2 py-1 rounded-full">10% fee</span>
            </button>
          </div>
          <Button onClick={handleSellProduct} className="kuyapads-button"><Plus className="w-4 h-4 mr-2" />Sell Product</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="md:col-span-2 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
            <input type="text" placeholder="Search products..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/60 focus:outline-none focus:border-yellow-400" />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
            <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} className="w-full pl-12 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-yellow-400 appearance-none">
              {categories.map(c => <option key={c} value={c} className="bg-slate-800">{c === 'all' ? 'All Categories' : c}</option>)}
            </select>
          </div>
        </div>

        {loading ? <p className="text-white text-center">Loading products...</p> : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <motion.div key={product.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="kuyapads-card p-6 hover:scale-105 transition-transform duration-300">
                <div className="mb-4"><img className="w-full h-48 object-cover rounded-lg" alt={product.title} src={product.image_url || "https://images.unsplash.com/photo-1559223669-e0065fa7f142"} /></div>
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm">{product.category}</span>
                    <div className="flex items-center space-x-1"><Star className="w-4 h-4 text-yellow-400 fill-current" /><span className="text-white text-sm">{product.rating}</span></div>
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{product.title}</h3>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-2xl font-bold text-yellow-400">₱{product.price.toLocaleString()}</div>
                  <div className="text-white/60 text-sm">{product.sales_count} sales</div>
                </div>
                <Button onClick={() => handlePurchase(product)} className="w-full kuyapads-button"><ShoppingBag className="w-4 h-4 mr-2" />Buy Now</Button>
              </motion.div>
            ))}
          </div>
        )}
        {products.length === 0 && !loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
            <ShoppingBag className="w-16 h-16 text-white/40 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">No products found</h3>
            <p className="text-white/60">Try adjusting your search or filters</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Shop;