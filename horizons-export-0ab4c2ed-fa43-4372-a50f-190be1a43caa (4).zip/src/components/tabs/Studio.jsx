import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Image, Video, Palette, Layers, Type, Download, Save, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Studio = ({ user, addEarnings }) => {
  const [activeStudio, setActiveStudio] = useState('photo');
  const [currentProject, setCurrentProject] = useState(null);
  const { toast } = useToast();

  const photoTemplates = [
    { id: 1, name: 'Social Media Post', category: 'Social', size: '1080x1080' },
    { id: 2, name: 'Instagram Story', category: 'Social', size: '1080x1920' },
    { id: 3, name: 'Business Card', category: 'Print', size: '3.5x2 in' },
    { id: 4, name: 'Flyer', category: 'Marketing', size: '8.5x11 in' },
  ];

  const videoTemplates = [
    { id: 1, name: 'TikTok Video', category: 'Social', duration: '15-60s' },
    { id: 2, name: 'Instagram Reel', category: 'Social', duration: '15-90s' },
    { id: 3, name: 'YouTube Intro', category: 'Video', duration: '5-10s' },
    { id: 4, name: 'Product Demo', category: 'Marketing', duration: '30-120s' },
  ];

  const handleCreateProject = async (template) => {
    if (!user) {
      toast({ title: "Please log in to start a project.", variant: "destructive" });
      return;
    }
    const { data, error } = await supabase.from('studio_projects').insert({
      user_id: user.id,
      type: activeStudio === 'photo' ? 'PhotoLab' : 'VideoLab',
      title: template.name
    }).select().single();

    if (error) {
      toast({ title: "Failed to create project", description: error.message, variant: "destructive" });
    } else {
      setCurrentProject({ ...template, ...data });
      addEarnings(2, 'Starting Studio Project');
      toast({
        title: "🎨 Project Created!",
        description: `Started new ${activeStudio === 'photo' ? 'PhotoLab' : 'VideoLab'} project: ${template.name}`,
      });
    }
  };

  const handleSaveProject = () => {
    addEarnings(5, 'Saving Studio Project');
    toast({
      title: "💾 Project Saved!",
      description: "Your project has been saved to your drive.",
    });
  };

  const handleNotImplemented = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Creator Studio</h1>
          <p className="text-white/70">Professional photo and video editing tools</p>
        </motion.div>

        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => setActiveStudio('photo')}
            className={`kuyapads-tab flex items-center space-x-2 ${
              activeStudio === 'photo' ? 'active' : ''
            }`}
          >
            <Image className="w-4 h-4" />
            <span>PhotoLab</span>
          </button>
          <button
            onClick={() => setActiveStudio('video')}
            className={`kuyapads-tab flex items-center space-x-2 ${
              activeStudio === 'video' ? 'active' : ''
            }`}
          >
            <Video className="w-4 h-4" />
            <span>VideoLab</span>
          </button>
        </div>

        {!currentProject ? (
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <h2 className="text-2xl font-bold text-white mb-4">
                Choose a {activeStudio === 'photo' ? 'PhotoLab' : 'VideoLab'} Template
              </h2>
              <div className="flex space-x-4">
                <Button onClick={handleNotImplemented} className="kuyapads-button">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Media
                </Button>
                <Button
                  variant="outline"
                  className="border-white/30 text-white hover:bg-white/10"
                  onClick={() => handleCreateProject({ name: 'Blank Canvas', category: 'Custom' })}
                >
                  Start from Scratch
                </Button>
              </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(activeStudio === 'photo' ? photoTemplates : videoTemplates).map((template, index) => (
                <motion.div
                  key={template.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="kuyapads-card p-6 hover:scale-105 transition-transform duration-300 cursor-pointer"
                  onClick={() => handleCreateProject(template)}
                >
                  <div className="w-full h-32 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg mb-4 flex items-center justify-center">
                    {activeStudio === 'photo' ? (
                      <Image className="w-12 h-12 text-white" />
                    ) : (
                      <Video className="w-12 h-12 text-white" />
                    )}
                  </div>
                  
                  <h3 className="text-lg font-semibold text-white mb-2">{template.name}</h3>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-white/70">{template.category}</span>
                    <span className="text-yellow-400">
                      {activeStudio === 'photo' ? template.size : template.duration}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="kuyapads-card p-8 text-center"
          >
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white">Editing: {currentProject.title}</h2>
                <Button onClick={() => setCurrentProject(null)} variant="outline" className="border-white/30 text-white hover:bg-white/10">Back</Button>
            </div>
            <Palette className="w-16 h-16 text-purple-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Full Editor Coming Soon</h3>
            <p className="text-white/70 mb-6">A powerful, in-browser editor is being built. For now, your project is saved.</p>
            <div className="flex gap-4 justify-center">
                <Button onClick={handleSaveProject} className="kuyapads-button"><Save className="w-4 h-4 mr-2" />Save Progress</Button>
                <Button onClick={handleNotImplemented} variant="outline" className="border-white/30 text-white hover:bg-white/10"><Download className="w-4 h-4 mr-2" />Export</Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Studio;