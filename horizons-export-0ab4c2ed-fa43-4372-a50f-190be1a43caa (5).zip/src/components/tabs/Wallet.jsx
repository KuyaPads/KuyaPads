import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Wallet as WalletIcon, Send, QrCode, History, CreditCard, Users, Globe, Shield, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Wallet = ({ user, profile, addEarnings }) => {
  const [activeTab, setActiveTab] = useState('balance');
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const referralCode = `KP${user?.id.substring(0, 8).toUpperCase() || '123456'}`;
  const { toast } = useToast();

  const fetchTransactions = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Error fetching transactions:', error);
      toast({ title: "Error fetching transactions", variant: "destructive" });
    } else {
      setTransactions(data);
    }
    setLoading(false);
  }, [user, toast]);

  useEffect(() => {
    if (activeTab === 'history') {
      fetchTransactions();
    }
  }, [activeTab, fetchTransactions]);

  const handleCopyReferral = () => {
    navigator.clipboard.writeText(`https://kuyapadsnetwork.com/ref/${referralCode}`);
    toast({
      title: "Referral Link Copied!",
      description: "Share with friends to earn 100 KPC per verified signup",
    });
  };

  const handleWithdraw = () => {
    toast({ title: "🚧 Withdraw feature coming soon!" });
  };
  
  const timeAgo = (date) => {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " years ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " months ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " days ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " hours ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutes ago";
    return "Just now";
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'history':
        return (
          <div className="kuyapads-card p-6">
            <h3 className="text-xl font-semibold text-white mb-6">Transaction History</h3>
            <div className="space-y-4">
              {loading ? <p className="text-white text-center">Loading history...</p> : transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${tx.type === 'earn' ? 'bg-green-500' : 'bg-red-500'} rounded-full flex items-center justify-center`}>
                      <Send className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-semibold">{tx.source}</div>
                      <div className="text-white/60 text-sm">{timeAgo(tx.created_at)}</div>
                    </div>
                  </div>
                  <div className={`${tx.type === 'earn' ? 'text-green-400' : 'text-red-400'} font-semibold`}>{tx.type === 'earn' ? '+' : '-'}{tx.amount} KPC</div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'referral':
        return (
          <div className="kuyapads-card p-8 text-center">
            <Users className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Refer & Earn</h3>
            <p className="text-white/70 mb-6">Invite friends to KuyaPads Network and earn 100 KPC for every verified user who signs up with your link.</p>
            <div className="flex items-center justify-center p-4 bg-white/10 border border-white/20 rounded-lg mb-6">
              <span className="text-white/80 truncate">{`https://kuyapadsnetwork.com/ref/${referralCode}`}</span>
            </div>
            <Button onClick={handleCopyReferral} className="kuyapads-button"><Copy className="w-4 h-4 mr-2" />Copy Referral Link</Button>
          </div>
        );
      default:
        return (
          <div className="kuyapads-card p-8 text-center">
            <WalletIcon className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Feature Coming Soon!</h3>
            <p className="text-white/70 mb-6">This wallet section is under construction.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">KuyaPads Wallet</h1>
          <p className="text-white/70">Manage your KPC tokens and earnings</p>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="kuyapads-card p-8 mb-8 pulse-glow">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <WalletIcon className="w-10 h-10 text-black" />
            </div>
            <h2 className="text-4xl font-bold text-white mb-2">{(profile?.kpc_balance || 0).toFixed(2)} KPC</h2>
            <p className="text-white/70 mb-6">≈ ${((profile?.kpc_balance || 0) * 0.1).toFixed(2)} USD</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={handleWithdraw} className="kuyapads-button"><Send className="w-4 h-4 mr-2" />Withdraw</Button>
              <Button onClick={() => toast({ title: "🚧 Receive feature coming soon!" })} variant="outline" className="border-white/30 text-white hover:bg-white/10"><QrCode className="w-4 h-4 mr-2" />Receive</Button>
            </div>
          </div>
        </motion.div>

        <div className="flex space-x-4 mb-8 overflow-x-auto">
          {[
            { id: 'balance', label: 'Balance', icon: WalletIcon },
            { id: 'referral', label: 'Referrals', icon: Users },
            { id: 'card', label: 'KuyaPads Visa', icon: CreditCard },
            { id: 'browser', label: 'Browser', icon: Globe },
            { id: 'history', label: 'History', icon: History }
          ].map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`kuyapads-tab flex items-center space-x-2 whitespace-nowrap ${activeTab === tab.id ? 'active' : ''}`}>
              <tab.icon className="w-4 h-4" /><span>{tab.label}</span>
            </button>
          ))}
        </div>

        <motion.div key={activeTab} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          {renderTabContent()}
        </motion.div>
      </div>
    </div>
  );
};

export default Wallet;
