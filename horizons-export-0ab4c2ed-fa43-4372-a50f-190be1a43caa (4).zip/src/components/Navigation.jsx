
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, User, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import LoginModal from '@/components/LoginModal';

const Navigation = ({ user, profile, onLogout }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const tabs = [
    { id: 'home', label: 'Home', path: '/' },
    { id: 'social', label: 'Social', path: '/social' },
    { id: 'wallet', label: 'Wallet', path: '/wallet' },
    { id: 'booking', label: 'Booking', path: '/booking' },
    { id: 'trading', label: 'Trading', path: '/trading' },
    { id: 'studio', label: 'Studio', path: '/studio' },
    { id: 'shop', label: 'Shop', path: '/shop' },
    { id: 'agency', label: 'Agency', path: '/agency' },
    { id: 'cloud', label: 'Cloud', path: '/cloud' },
    { id: 'padify', label: 'Padify', path: '/padify' },
    { id: 'kuyamind', label: 'KuyaMind', path: '/kuyamind' },
    { id: 'learn-to-earn', label: 'Learn-to-Earn', path: '/learn-to-earn' },
    { id: 'watch-to-earn', label: 'Watch-to-Earn', path: '/watch-to-earn' },
    { id: 'support', label: 'Support', path: '/support' },
  ];

  const handleTabClick = (path) => {
    if (!user && path !== '/') {
      setShowLoginModal(true);
      return;
    }
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-40 bg-black/20 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center space-x-2 cursor-pointer">
              <motion.div whileHover={{ scale: 1.05 }}>
                <img src="https://horizons-cdn.hostinger.com/0ab4c2ed-fa43-4372-a50f-190be1a43caa/bfb567a0fadd3636d597c2c5f18977b5.png" alt="KuyaPads Network Logo" className="h-10 w-auto" />
              </motion.div>
            </Link>

            <div className="hidden lg:flex items-center space-x-1 overflow-x-auto scrollbar-hide">
              {tabs.slice(0, 8).map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleTabClick(tab.path)}
                  className={`kuyapads-tab whitespace-nowrap ${
                    location.pathname === tab.path ? 'active' : ''
                  }`}
                >
                  {tab.label}
                </button>
              ))}
              
              <div className="relative group">
                <button className="kuyapads-tab">More</button>
                <div className="absolute top-full right-0 mt-2 w-48 bg-black/90 backdrop-blur-lg rounded-lg border border-white/20 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                  {tabs.slice(8).map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => handleTabClick(tab.path)}
                      className="block w-full text-left px-4 py-2 text-white/70 hover:text-white hover:bg-white/10 first:rounded-t-lg last:rounded-b-lg"
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {user && profile ? (
                <div className="flex items-center space-x-2">
                  <div className="flex items-center space-x-2 bg-white/10 rounded-lg px-3 py-1">
                    <User className="w-4 h-4 text-yellow-400" />
                    <span className="text-white text-sm">{profile.full_name || user.email}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onLogout}
                    className="text-white hover:bg-white/10"
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={() => setShowLoginModal(true)}
                  className="kuyapads-button"
                >
                  Login
                </Button>
              )}

              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden text-white p-2"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-black/90 backdrop-blur-lg border-t border-white/10"
          >
            <div className="px-4 py-4 space-y-2 max-h-96 overflow-y-auto">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => handleTabClick(tab.path)}
                  className={`block w-full text-left px-4 py-3 rounded-lg transition-all duration-300 ${
                    location.pathname === tab.path
                      ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-black font-semibold'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </nav>

      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
      />
    </>
  );
};

export default Navigation;
