import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Calendar, Users, Car, Camera, Star, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Booking = ({ user, addEarnings }) => {
  const [tours, setTours] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTour, setSelectedTour] = useState(null);
  const [bookingData, setBookingData] = useState({ date: '', guests: 1 });
  const { toast } = useToast();

  const fetchTours = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('tours').select('*');
    if (error) {
      console.error('Error fetching tours:', error);
      toast({ title: "Error fetching tours", variant: "destructive" });
    } else {
      setTours(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchTours();
  }, [fetchTours]);

  const handleBookTour = async () => {
    if (!user || !selectedTour || !bookingData.date) {
      toast({ title: "Please complete booking details", variant: "destructive" });
      return;
    }

    const totalCost = selectedTour.base_price * bookingData.guests;
    const { error } = await supabase.from('bookings').insert({
      user_id: user.id,
      tour_id: selectedTour.id,
      booking_date: bookingData.date,
      guests: bookingData.guests,
      total_cost: totalCost,
      status: 'confirmed'
    });

    if (error) {
      toast({ title: "Booking failed", description: error.message, variant: "destructive" });
    } else {
      addEarnings(Math.floor(totalCost * 0.02), 'Tour Booking Commission');
      toast({ title: "🎉 Tour Booked Successfully!", description: `Your ${selectedTour.title} is confirmed for ${bookingData.date}.` });
      setSelectedTour(null);
      setBookingData({ date: '', guests: 1 });
    }
  };

  if (loading) {
    return <div className="text-white text-center p-10">Loading Tours...</div>;
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">KuyaPads Catanduanes Travel & Tours</h1>
          <p className="text-xl text-white/70 mb-6">Discover The Happy Island with exclusive tour packages</p>
        </motion.div>

        {!selectedTour ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {tours.map((tour, index) => (
              <motion.div key={tour.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="kuyapads-card p-6 hover:scale-105 transition-transform duration-300 cursor-pointer" onClick={() => setSelectedTour(tour)}>
                <div className="mb-4"><img className="w-full h-48 object-cover rounded-lg" alt={tour.title} src={tour.image_url || "https://images.unsplash.com/photo-1569372314472-8aea12c94019"} /></div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-semibold text-white">{tour.title}</h3>
                  <div className="flex items-center space-x-1"><Star className="w-4 h-4 text-yellow-400 fill-current" /><span className="text-white text-sm">{tour.rating}</span></div>
                </div>
                <p className="text-white/70 mb-4">{tour.description}</p>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4 text-white/60"><div className="flex items-center space-x-1"><Clock className="w-4 h-4" /><span>{tour.duration}</span></div></div>
                  <div className="text-2xl font-bold text-yellow-400">₱{tour.base_price.toLocaleString()}</div>
                </div>
                <Button className="w-full kuyapads-button">Book This Tour</Button>
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold text-white">Book {selectedTour.title}</h2>
              <Button onClick={() => setSelectedTour(null)} variant="outline" className="border-white/30 text-white hover:bg-white/10">Back to Tours</Button>
            </div>
            <div className="kuyapads-card p-6">
              <h3 className="text-xl font-semibold text-white mb-6">Booking Details</h3>
              <div className="space-y-6">
                <div>
                  <label className="block text-white/70 text-sm mb-2">Select Date</label>
                  <input type="date" value={bookingData.date} onChange={(e) => setBookingData(prev => ({ ...prev, date: e.target.value }))} min={new Date().toISOString().split('T')[0]} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-yellow-400" />
                </div>
                <div>
                  <label className="block text-white/70 text-sm mb-2">Number of Guests</label>
                  <select value={bookingData.guests} onChange={(e) => setBookingData(prev => ({ ...prev, guests: parseInt(e.target.value) }))} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-yellow-400">
                    {[...Array(10).keys()].map(i => <option key={i + 1} value={i + 1}>{i + 1} Guest{i > 0 ? 's' : ''}</option>)}
                  </select>
                </div>
                <div className="border-t border-white/20 pt-4">
                  <div className="flex justify-between text-lg font-semibold">
                    <span className="text-white">Total</span>
                    <span className="text-yellow-400">₱{(selectedTour.base_price * bookingData.guests).toLocaleString()}</span>
                  </div>
                </div>
                <Button onClick={handleBookTour} className="w-full kuyapads-button" disabled={!bookingData.date}>Confirm Booking</Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Booking;