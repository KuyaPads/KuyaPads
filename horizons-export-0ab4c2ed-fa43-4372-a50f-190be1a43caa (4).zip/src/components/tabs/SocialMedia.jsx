import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Share2, Image, Video, Users, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const SocialMedia = ({ user, profile, addEarnings }) => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState('');
  const [activeTab, setActiveTab] = useState('feed');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('posts')
      .select('*, profile:profiles(full_name, avatar_url), reactions(user_id, type)')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching posts:', error);
      toast({ title: "Error fetching posts", variant: "destructive" });
    } else {
      const processedPosts = data.map(post => ({
        ...post,
        likes: post.reactions.filter(r => r.type === 'like').length,
        liked: user ? post.reactions.some(r => r.user_id === user.id && r.type === 'like') : false,
        comments: 0, // Placeholder
        shares: 0, // Placeholder
      }));
      setPosts(processedPosts);
    }
    setLoading(false);
  }, [toast, user]);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  const handleCreatePost = async () => {
    if (!newPost.trim() || !user) return;
    const { data, error } = await supabase
      .from('posts')
      .insert({ user_id: user.id, content: newPost })
      .select('*, profile:profiles(full_name, avatar_url), reactions(user_id, type)')
      .single();

    if (error) {
      toast({ title: "Failed to create post", variant: "destructive" });
    } else {
      const newPostData = {
        ...data,
        likes: 0,
        liked: false,
        comments: 0,
        shares: 0,
      };
      setPosts(prev => [newPostData, ...prev]);
      setNewPost('');
      addEarnings(5, 'Creating Post');
    }
  };

  const handleLike = async (postId, isLiked) => {
    if (!user) return;
    if (isLiked) {
      await supabase.from('reactions').delete().match({ post_id: postId, user_id: user.id, type: 'like' });
    } else {
      await supabase.from('reactions').insert({ post_id: postId, user_id: user.id, type: 'like' });
      addEarnings(1, 'Liking Post');
    }
    fetchPosts();
  };

  const handleComment = (postId) => {
    addEarnings(2, 'Commenting');
    toast({ title: "🚧 Comment feature coming soon!" });
  };

  const handleShare = (postId) => {
    addEarnings(3, 'Sharing Post');
    toast({ title: "🚧 Share feature coming soon!" });
  };

  const timeAgo = (date) => {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " years ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " months ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " days ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " hours ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutes ago";
    return "Just now";
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Social Media</h1>
          <p className="text-white/70">Connect, share, and earn KPC with every interaction</p>
        </motion.div>

        <div className="flex space-x-4 mb-8">
          {['feed', 'groups', 'live'].map((tab) => (
            <button key={tab} onClick={() => setActiveTab(tab)} className={`kuyapads-tab capitalize ${activeTab === tab ? 'active' : ''}`}>
              {tab === 'live' && <span className="mr-2">🔴</span>}
              {tab}
            </button>
          ))}
        </div>

        {activeTab === 'feed' && (
          <>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="kuyapads-card p-6 mb-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-black font-semibold">
                    {profile?.full_name?.split(' ').map(n => n[0]).join('') || 'U'}
                  </span>
                </div>
                <div className="flex-1">
                  <textarea value={newPost} onChange={(e) => setNewPost(e.target.value)} placeholder="What's on your mind? Share and earn KPC!" className="w-full bg-white/10 border border-white/20 rounded-lg p-4 text-white placeholder-white/60 resize-none focus:outline-none focus:border-yellow-400" rows={3} />
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex space-x-4">
                      <button className="flex items-center space-x-2 text-white/70 hover:text-white"><Image className="w-5 h-5" /><span>Photo</span></button>
                      <button className="flex items-center space-x-2 text-white/70 hover:text-white"><Video className="w-5 h-5" /><span>Video</span></button>
                    </div>
                    <Button onClick={handleCreatePost} disabled={!newPost.trim()} className="kuyapads-button"><Send className="w-4 h-4 mr-2" />Post (+5 KPC)</Button>
                  </div>
                </div>
              </div>
            </motion.div>

            <div className="space-y-6">
              {loading ? <p className="text-white text-center">Loading posts...</p> : posts.map((post, index) => (
                <motion.div key={post.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="kuyapads-card p-6">
                  <div className="flex items-start space-x-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-semibold">{post.profile?.full_name?.split(' ').map(n => n[0]).join('') || 'A'}</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-white">{post.profile?.full_name || 'Anonymous'}</h3>
                      <p className="text-white/60 text-sm">{timeAgo(post.created_at)}</p>
                    </div>
                  </div>
                  <p className="text-white mb-4">{post.content}</p>
                  <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <button onClick={() => handleLike(post.id, post.liked)} className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${post.liked ? 'text-red-400 bg-red-400/10' : 'text-white/70 hover:text-white hover:bg-white/10'}`}>
                      <Heart className={`w-5 h-5 ${post.liked ? 'fill-current' : ''}`} />
                      <span>{post.likes} (+1 KPC)</span>
                    </button>
                    <button onClick={() => handleComment(post.id)} className="flex items-center space-x-2 px-4 py-2 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-all">
                      <MessageCircle className="w-5 h-5" />
                      <span>{post.comments} (+2 KPC)</span>
                    </button>
                    <button onClick={() => handleShare(post.id)} className="flex items-center space-x-2 px-4 py-2 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-all">
                      <Share2 className="w-5 h-5" />
                      <span>{post.shares} (+3 KPC)</span>
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        )}

        {activeTab !== 'feed' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="kuyapads-card p-8 text-center">
            <Users className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Feature Coming Soon!</h3>
            <p className="text-white/70 mb-6">This section is under construction.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default SocialMedia;