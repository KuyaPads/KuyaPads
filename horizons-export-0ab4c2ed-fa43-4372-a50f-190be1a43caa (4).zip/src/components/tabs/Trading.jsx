import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, BarChart3, DollarSign, Bitcoin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Trading = ({ user, addEarnings }) => {
  const [activeMarket, setActiveMarket] = useState('crypto');
  const [selectedSymbol, setSelectedSymbol] = useState('BTC/USD');
  const [orderType, setOrderType] = useState('market');
  const [orderSide, setOrderSide] = useState('buy');
  const [amount, setAmount] = useState('');
  const [price, setPrice] = useState('');
  const { toast } = useToast();

  const markets = {
    crypto: [{ symbol: 'BTC/USD', price: 43250.50, change: 2.45 }, { symbol: 'ETH/USD', price: 2680.75, change: -1.23 }],
    forex: [{ symbol: 'EUR/USD', price: 1.0875, change: 0.12 }, { symbol: 'GBP/USD', price: 1.2650, change: -0.34 }],
    stocks: [{ symbol: 'AAPL', price: 189.50, change: 1.25 }, { symbol: 'GOOGL', price: 142.80, change: -0.78 }],
    binary: [{ symbol: 'BTC Call 60s', price: 0.85, change: 5.23 }, { symbol: 'EUR/USD Put 5m', price: 0.72, change: -2.15 }],
  };

  const handlePlaceOrder = async () => {
    if (!user || !amount || (orderType === 'limit' && !price)) {
      toast({ title: "Please fill in all order details", variant: "destructive" });
      return;
    }

    const { error } = await supabase.from('simulated_orders').insert({
      user_id: user.id,
      symbol: selectedSymbol,
      side: orderSide,
      type: orderType,
      amount: parseFloat(amount),
      price: orderType === 'limit' ? parseFloat(price) : null,
      status: 'filled'
    });

    if (error) {
      toast({ title: "Failed to place order", description: error.message, variant: "destructive" });
    } else {
      addEarnings(1, 'Trading Simulation');
      toast({ title: "🎉 Simulated Order Placed!", description: `${orderSide.toUpperCase()} ${amount} ${selectedSymbol}` });
      setAmount('');
      setPrice('');
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Trading Hub</h1>
          <p className="text-white/70">Trade crypto, forex, stocks, and binary options</p>
          <div className="mt-4 p-4 bg-yellow-400/10 border border-yellow-400/20 rounded-lg">
            <p className="text-yellow-400 text-sm">⚠️ This is a simulation environment. Real trading coming soon!</p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="kuyapads-card p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Place Order</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-white/70 text-sm mb-2">Symbol</label>
                  <select value={selectedSymbol} onChange={(e) => setSelectedSymbol(e.target.value)} className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-yellow-400">
                    {markets[activeMarket].map((item) => <option key={item.symbol} value={item.symbol}>{item.symbol}</option>)}
                  </select>
                </div>
                <div className="flex space-x-2">
                  <button onClick={() => setOrderSide('buy')} className={`flex-1 py-2 rounded-lg transition-all ${orderSide === 'buy' ? 'bg-green-500 text-white' : 'bg-white/10 text-white/70 hover:bg-white/20'}`}>Buy</button>
                  <button onClick={() => setOrderSide('sell')} className={`flex-1 py-2 rounded-lg transition-all ${orderSide === 'sell' ? 'bg-red-500 text-white' : 'bg-white/10 text-white/70 hover:bg-white/20'}`}>Sell</button>
                </div>
                <div>
                  <label className="block text-white/70 text-sm mb-2">Amount</label>
                  <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-white/60 focus:outline-none focus:border-yellow-400" />
                </div>
                <Button onClick={handlePlaceOrder} className={`w-full ${orderSide === 'buy' ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600'} text-white font-semibold`}>
                  {orderSide === 'buy' ? 'Buy' : 'Sell'} {selectedSymbol}
                </Button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="kuyapads-card p-6 mb-6">
              <div className="h-64 bg-white/5 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="w-16 h-16 text-white/40 mx-auto mb-4" />
                  <p className="text-white/60">TradingView-style charts coming soon!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Trading;