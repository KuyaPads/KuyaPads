import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Users, Briefcase, Star, Clock, DollarSign, Send, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Agency = ({ user, addEarnings }) => {
  const [activeTab, setActiveTab] = useState('browse');
  const [jobs, setJobs] = useState([]);
  const [freelancers, setFreelancers] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const jobCategories = [
    'All', 'Virtual Assistant', 'Content Writing', 'Graphic Design', 
    'Video Editing', 'Web Development', 'Digital Marketing', 'Tutoring'
  ];

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('jobs').select('*').order('created_at', { ascending: false });
    if (error) {
      console.error('Error fetching jobs:', error);
      toast({ title: "Error fetching jobs", variant: "destructive" });
    } else {
      setJobs(data);
    }
    setLoading(false);
  }, [toast]);

  const fetchFreelancers = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('freelancers').select('*, profile:profiles(full_name)');
    if (error) {
      console.error('Error fetching freelancers:', error);
      toast({ title: "Error fetching freelancers", variant: "destructive" });
    } else {
      setFreelancers(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    if (activeTab === 'browse') {
      fetchJobs();
    } else if (activeTab === 'freelancers') {
      fetchFreelancers();
    }
  }, [activeTab, fetchJobs, fetchFreelancers]);

  const handleApplyJob = (job) => {
    addEarnings(5, 'Job Application Submitted');
    toast({
      title: "🎉 Application Submitted!",
      description: `Your proposal for "${job.title}" has been sent.`,
    });
  };

  const handleHireFreelancer = (freelancer) => {
    addEarnings(10, 'Freelancer Hire Commission');
    toast({
      title: "🤝 Freelancer Hired!",
      description: `${freelancer.profile.full_name} has been hired. Project workspace created.`,
    });
  };

  const handlePostJob = async (e) => {
    e.preventDefault();
    if (!user) {
      toast({ title: "Please log in to post a job.", variant: "destructive" });
      return;
    }
    const formData = new FormData(e.target);
    const jobData = Object.fromEntries(formData.entries());
    
    const { error } = await supabase.from('jobs').insert({
      client_id: user.id,
      title: jobData.title,
      category: jobData.category,
      budget: parseFloat(jobData.budget),
      description: jobData.description,
      duration: jobData.duration,
      status: 'open'
    });

    if (error) {
      toast({ title: "Failed to post job", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "🎉 Job Posted Successfully!" });
      e.target.reset();
      setActiveTab('browse');
      fetchJobs();
    }
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">KuyaPads Agency</h1>
          <p className="text-white/70">Connect with talented freelancers and find your next opportunity</p>
        </motion.div>

        <div className="flex space-x-4 mb-8">
          {[{ id: 'browse', label: 'Browse Jobs', icon: Briefcase }, { id: 'freelancers', label: 'Find Talent', icon: Users }, { id: 'post', label: 'Post Job', icon: Send }].map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`kuyapads-tab flex items-center space-x-2 ${activeTab === tab.id ? 'active' : ''}`}>
              <tab.icon className="w-4 h-4" /><span>{tab.label}</span>
            </button>
          ))}
        </div>

        {activeTab === 'browse' && (
          <div className="space-y-6">
            {loading ? <p className="text-white text-center">Loading jobs...</p> : jobs.map((job, index) => (
              <motion.div key={job.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="kuyapads-card p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-white mb-2">{job.title}</h3>
                    <div className="flex items-center space-x-4 text-white/60 text-sm mb-3">
                      <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full">{job.category}</span>
                      <div className="flex items-center space-x-1"><Clock className="w-4 h-4" /><span>{job.duration}</span></div>
                      <div className="flex items-center space-x-1"><DollarSign className="w-4 h-4" /><span>₱{job.budget?.toLocaleString()}</span></div>
                    </div>
                    <p className="text-white/70 mb-4">{job.description}</p>
                  </div>
                  <div className="ml-6 text-right">
                    <Button onClick={() => handleApplyJob(job)} className="kuyapads-button">Apply Now</Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'freelancers' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? <p className="text-white text-center col-span-full">Loading freelancers...</p> : freelancers.map((freelancer, index) => (
              <motion.div key={freelancer.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }} className="kuyapads-card p-6">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-3"><span className="text-white font-semibold text-lg">{freelancer.profile?.full_name?.split(' ').map(n=>n[0]).join('')}</span></div>
                  <h3 className="text-lg font-semibold text-white">{freelancer.profile?.full_name}</h3>
                  <p className="text-white/70">{freelancer.title}</p>
                </div>
                <div className="space-y-3 mb-4">
                  <div className="flex items-center justify-between"><span className="text-white/70">Rating</span><div className="flex items-center space-x-1"><Star className="w-4 h-4 text-yellow-400 fill-current" /><span className="text-white">{freelancer.rating}</span><span className="text-white/60">({freelancer.reviews_count})</span></div></div>
                  <div className="flex items-center justify-between"><span className="text-white/70">Hourly Rate</span><span className="text-yellow-400 font-semibold">₱{freelancer.hourly_rate}/hr</span></div>
                  <div className="flex items-center justify-between"><span className="text-white/70">Completed Jobs</span><span className="text-white">{freelancer.completed_jobs}</span></div>
                </div>
                <Button onClick={() => handleHireFreelancer(freelancer)} className="w-full kuyapads-button">Hire Now</Button>
              </motion.div>
            ))}
          </div>
        )}

        {activeTab === 'post' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl mx-auto">
            <form onSubmit={handlePostJob} className="kuyapads-card p-8">
              <h2 className="text-2xl font-bold text-white mb-6">Post a New Job</h2>
              <div className="space-y-6">
                <div><label className="block text-white/70 text-sm mb-2">Job Title</label><input type="text" name="title" placeholder="e.g. Social Media Manager Needed" required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:border-yellow-400" /></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div><label className="block text-white/70 text-sm mb-2">Category</label><select name="category" required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-yellow-400">{jobCategories.slice(1).map(c => <option key={c} value={c} className="bg-slate-800">{c}</option>)}</select></div>
                  <div><label className="block text-white/70 text-sm mb-2">Budget (PHP)</label><input type="number" name="budget" placeholder="e.g. 15000" required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:border-yellow-400" /></div>
                </div>
                <div><label className="block text-white/70 text-sm mb-2">Job Description</label><textarea name="description" rows={6} placeholder="Describe your project requirements..." required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 resize-none focus:outline-none focus:border-yellow-400" /></div>
                <div><label className="block text-white/70 text-sm mb-2">Project Duration</label><select name="duration" required className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-yellow-400"><option value="1-week" className="bg-slate-800">Less than 1 week</option><option value="1-4-weeks" className="bg-slate-800">1-4 weeks</option><option value="1-3-months" className="bg-slate-800">1-3 months</option><option value="ongoing" className="bg-slate-800">Ongoing</option></select></div>
                <div className="bg-yellow-400/10 border border-yellow-400/20 rounded-lg p-4"><h4 className="text-yellow-400 font-semibold mb-2">Platform Fee: 30%</h4><p className="text-yellow-400/80 text-sm">KuyaPads Agency charges a 30% commission on all project payments.</p></div>
                <Button type="submit" className="w-full kuyapads-button">Post Job</Button>
              </div>
            </form>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Agency;