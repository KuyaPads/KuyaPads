
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Play, Star, Users, TrendingUp, Globe, Shield, Award, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Homepage = () => {
  const features = [
    {
      icon: Users,
      title: 'Social Media',
      description: 'Connect, share, and earn KPC with every interaction',
      color: 'from-blue-500 to-blue-600',
      path: '/social'
    },
    {
      icon: TrendingUp,
      title: 'Trading Hub',
      description: 'Trade crypto, forex, and stocks with advanced tools',
      color: 'from-green-500 to-green-600',
      path: '/trading'
    },
    {
      icon: Globe,
      title: 'Travel & Tours',
      description: 'Explore Catanduanes with exclusive tour packages',
      color: 'from-yellow-500 to-yellow-600',
      path: '/booking'
    },
    {
      icon: Zap,
      title: 'Creator Studio',
      description: 'Design graphics and edit videos like a pro',
      color: 'from-purple-500 to-purple-600',
      path: '/studio'
    }
  ];

  const stats = [
    { label: 'Active Users', value: '50K+' },
    { label: 'KPC Distributed', value: '1M+' },
    { label: 'Tours Booked', value: '2.5K+' },
    { label: 'Creators Earning', value: '10K+' }
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-blue-500/20 to-green-500/20" />
        
        <div className="relative max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-yellow-400 via-blue-500 to-green-500 bg-clip-text text-transparent">
                KuyaPads Network
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-3xl mx-auto">
              Create • Earn • Explore — The ultimate platform where every action rewards you with KPC tokens
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/wallet">
                <Button className="kuyapads-button text-lg px-8 py-4">
                  Get Started
                </Button>
              </Link>
              <Button
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 text-lg px-8 py-4"
              >
                <Play className="w-5 h-5 mr-2" />
                Watch Demo
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mt-16 kuyapads-card p-8 max-w-4xl mx-auto"
          >
            <div className="flex items-center justify-center mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-black font-bold text-xl">AP</span>
              </div>
              <div className="ml-4 text-left">
                <h3 className="text-xl font-bold text-white">Anthony "KuyaPads" Padel</h3>
                <p className="text-yellow-400">Founder & CEO</p>
              </div>
            </div>
            <p className="text-white/80 text-lg leading-relaxed">
              "From The Happy Island of Catanduanes to the world, KuyaPads Network is my vision to uplift lives through education, opportunity, and decentralized earnings. Every feature is designed to empower you to create, earn, and explore without limits."
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-white mb-4">
              Everything You Need in One Platform
            </h2>
            <p className="text-xl text-white/70">
              Discover all the ways you can earn KPC tokens
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Link to={feature.path} key={feature.title}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  className="kuyapads-card p-6 h-full hover:scale-105 transition-transform duration-300 cursor-pointer"
                >
                  <div className={`w-12 h-12 bg-gradient-to-r ${feature.color} rounded-lg flex items-center justify-center mb-4`}>
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                  <p className="text-white/70">{feature.description}</p>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-black/20">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl font-bold text-yellow-400 mb-2">{stat.value}</div>
                <div className="text-white/70">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section id="downloads" className="py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold text-white mb-12">Download Our Apps</h2>
            <div className="flex flex-wrap justify-center items-center gap-8">
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 text-lg px-8 py-4">Android (APK)</Button>
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 text-lg px-8 py-4">iOS</Button>
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 text-lg px-8 py-4">Windows</Button>
              <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 text-lg px-8 py-4">macOS</Button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-20 px-4 bg-gradient-to-r from-yellow-400/10 via-blue-500/10 to-green-500/10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Start Earning?
            </h2>
            <p className="text-xl text-white/80 mb-8">
              Join thousands of creators, traders, and travelers earning KPC tokens daily
            </p>
            <Link to="/wallet">
              <Button className="kuyapads-button text-lg px-8 py-4">
                Join KuyaPads Network
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Homepage;
