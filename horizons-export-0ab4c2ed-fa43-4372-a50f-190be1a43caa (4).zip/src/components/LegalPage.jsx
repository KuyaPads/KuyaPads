
import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';

const LegalPage = ({ type }) => {
  const content = {
    privacy: {
      title: 'Privacy Policy',
      text: 'Your privacy is important to us. It is KuyaPads Network\'s policy to respect your privacy regarding any information we may collect from you across our website, and other sites we own and operate. We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used. This is a placeholder text.'
    },
    terms: {
      title: 'Terms of Service',
      text: 'By accessing the website at KuyaPads Network, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site. The materials contained in this website are protected by applicable copyright and trademark law. This is a placeholder text.'
    },
    policy: {
      title: 'Platform Policy',
      text: 'This document outlines the general policies for using the KuyaPads Network platform. It covers acceptable use, content guidelines, and community standards. All users are expected to adhere to these policies to maintain a safe and positive environment for everyone. Violations may result in account suspension or termination. This is a placeholder text.'
    },
    cookies: {
      title: 'Cookie Policy',
      text: 'We use cookies to help improve your experience of our website. This cookie policy is part of KuyaPads Network\'s privacy policy, and covers the use of cookies between your device and our site. We also provide basic information on third-party services we may use, who may also use cookies as part of their service, though they are not covered by our policy. This is a placeholder text.'
    },
    about: {
      title: 'About Us',
      text: 'KuyaPads Network was founded by Anthony "KuyaPads" Padel with a mission to uplift lives globally through education, opportunity, and decentralized earnings, starting from The Happy Island, Catanduanes. We are an all-in-one digital ecosystem designed to empower creators, entrepreneurs, and explorers. Our platform integrates social media, e-commerce, travel, finance, and more, all powered by our native token, KuyaPads Coin (KPC). This is a placeholder text.'
    }
  };

  const pageContent = content[type] || { title: 'Page Not Found', text: 'The content for this page could not be found.' };

  return (
    <div className="min-h-screen py-12 px-4">
      <Helmet>
        <title>{pageContent.title} - KuyaPads Network</title>
        <meta name="description" content={`Read the ${pageContent.title} for KuyaPads Network.`} />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto kuyapads-card p-8 md:p-12"
      >
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-8">{pageContent.title}</h1>
        <div className="prose prose-invert max-w-none text-white/80 leading-relaxed space-y-4">
          <p>{pageContent.text}</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor. Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi. Proin porttitor, orci nec nonummy molestie, enim est eleifend mi, non fermentum diam nisl sit amet erat. Duis semper. Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue. Ut in risus volutpat libero pharetra tempor. Cras vestibulum bibendum augue. Praesent egestas leo in pede. Praesent blandit odio eu enim. Pellentesque sed dui ut augue blandit sodales. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Aliquam nibh.</p>
          <p>Mauris ac mauris sed pede pellentesque fermentum. Maecenas adipiscing ante non diam. Proin magna. Sed in lacus ut enim adipiscing aliquet. Nulla venenatis. In pede mi, aliquet sit amet, euismod in, auctor ut, ligula. Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, lobortis dignissim, pulvinar ac, lorem. Vestibulum sed ante. Donec sagittis euismod purus. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
        </div>
      </motion.div>
    </div>
  );
};

export default LegalPage;
