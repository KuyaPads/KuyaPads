import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Cloud as CloudIcon, Server, Globe, Zap, Shield, BarChart3, Settings, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const Cloud = ({ user, addEarnings }) => {
  const [activeTab, setActiveTab] = useState('hosting');
  const [hostingPlans, setHostingPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchPlans = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('hosting_plans').select('*');
    if (error) {
      console.error('Error fetching hosting plans:', error);
      toast({ title: "Error fetching plans", variant: "destructive" });
    } else {
      setHostingPlans(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    if (activeTab === 'hosting') {
      fetchPlans();
    }
  }, [activeTab, fetchPlans]);

  const handleSelectPlan = (plan) => {
    if (!user) {
      toast({ title: "Please log in to select a plan.", variant: "destructive" });
      return;
    }
    addEarnings(Math.floor(plan.price * 0.02), 'Cloud Hosting Purchase');
    toast({
      title: "🎉 Hosting Plan Activated!",
      description: `${plan.name} plan activated. You can now create websites and manage domains.`,
    });
  };

  const handleNotImplemented = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-white mb-4">KuyaPads Cloud</h1>
          <p className="text-xl text-white/70 mb-6">
            Independent hosting, domains, and website builder
          </p>
          <div className="flex items-center justify-center space-x-6 text-white/60">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-green-400" />
              <span>99.9% Uptime</span>
            </div>
            <div className="flex items-center space-x-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span>Lightning Fast</span>
            </div>
            <div className="flex items-center space-x-2">
              <Globe className="w-5 h-5 text-blue-400" />
              <span>Global CDN</span>
            </div>
          </div>
        </motion.div>

        <div className="flex space-x-4 mb-8 justify-center">
          {[
            { id: 'hosting', label: 'Hosting Plans', icon: Server },
            { id: 'websites', label: 'My Websites', icon: Globe },
            { id: 'domains', label: 'Domains', icon: Settings },
            { id: 'status', label: 'Status', icon: BarChart3 }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`kuyapads-tab flex items-center space-x-2 ${
                activeTab === tab.id ? 'active' : ''
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {activeTab === 'hosting' && (
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-bold text-white mb-4">Choose Your Hosting Plan</h2>
              <p className="text-white/70">No free trials - Professional hosting from day one</p>
            </motion.div>

            {loading ? <p className="text-white text-center">Loading plans...</p> : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {hostingPlans.map((plan, index) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`kuyapads-card p-8 text-center relative ${
                      plan.is_popular ? 'ring-2 ring-yellow-400' : ''
                    }`}
                  >
                    {plan.is_popular && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <span className="bg-yellow-400 text-black px-4 py-1 rounded-full text-sm font-semibold">
                          Most Popular
                        </span>
                      </div>
                    )}
                    
                    <h3 className="text-2xl font-bold text-white mb-4">{plan.name}</h3>
                    <div className="text-4xl font-bold text-yellow-400 mb-2">
                      ₱{plan.price.toLocaleString()}
                    </div>
                    <p className="text-white/60 mb-8">per month</p>
                    
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="text-white/80 flex items-center justify-center">
                          <span className="w-2 h-2 bg-green-400 rounded-full mr-3"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    
                    <Button
                      onClick={() => handleSelectPlan(plan)}
                      className={`w-full ${
                        plan.is_popular 
                          ? 'kuyapads-button' 
                          : 'bg-white/10 hover:bg-white/20 text-white border border-white/30'
                      }`}
                    >
                      Select Plan
                    </Button>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab !== 'hosting' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="kuyapads-card p-8 text-center">
            <CloudIcon className="w-16 h-16 text-blue-400 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-white mb-4">Full Functionality Coming Soon</h3>
            <p className="text-white/70 mb-6">This section is under active development to bring you a complete cloud management experience.</p>
            <Button onClick={handleNotImplemented} className="kuyapads-button">Request This Feature</Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Cloud;