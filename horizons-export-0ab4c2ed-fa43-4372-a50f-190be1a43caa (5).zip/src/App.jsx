import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import EarningsWidget from '@/components/EarningsWidget';
import Homepage from '@/components/tabs/Homepage';
import SocialMedia from '@/components/tabs/SocialMedia';
import Wallet from '@/components/tabs/Wallet';
import Booking from '@/components/tabs/Booking';
import Trading from '@/components/tabs/Trading';
import Studio from '@/components/tabs/Studio';
import Shop from '@/components/tabs/Shop';
import Agency from '@/components/tabs/Agency';
import Cloud from '@/components/tabs/Cloud';
import Padify from '@/components/tabs/Padify';
import KuyaMind from '@/components/tabs/KuyaMind';
import LearnToEarn from '@/components/tabs/LearnToEarn';
import WatchToEarn from '@/components/tabs/WatchToEarn';
import Support from '@/components/tabs/Support';
import NotFound from '@/components/NotFound';
import LegalPage from '@/components/LegalPage';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

function App() {
  const { user, signOut } = useAuth();
  const [profile, setProfile] = useState(null);
  const { toast } = useToast();
  const location = useLocation();

  const fetchProfile = useCallback(async () => {
    if (user) {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) {
        console.error('Error fetching profile:', error);
      } else if (data) {
        setProfile(data);
      }
    } else {
      setProfile(null);
    }
  }, [user]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const addEarnings = useCallback(async (amount, source) => {
    if (!user || !profile) return;

    const newBalance = (profile.kpc_balance || 0) + amount;
    const newTotalEarnings = (profile.total_earnings || 0) + amount;

    const { error: updateError } = await supabase
      .from('profiles')
      .update({ kpc_balance: newBalance, total_earnings: newTotalEarnings })
      .eq('id', user.id);

    if (updateError) {
      console.error('Error updating balance:', updateError);
      return;
    }

    const { error: txError } = await supabase
      .from('transactions')
      .insert({ user_id: user.id, type: 'earn', source, amount, status: 'completed' });

    if (txError) {
      console.error('Error creating transaction:', txError);
    }

    setProfile(prev => ({
      ...prev,
      kpc_balance: newBalance,
      total_earnings: newTotalEarnings,
    }));
    
    toast({
      title: "🎉 KPC Earned!",
      description: `+${amount.toFixed(2)} KPC from ${source}`,
      duration: 3000,
    });
  }, [user, profile, toast]);

  const handleLogout = async () => {
    await signOut();
    setProfile(null);
  };

  const commonProps = { user, profile, addEarnings, fetchProfile };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex flex-col">
      <Helmet>
        <title>KuyaPads Network - Create • Earn • Explore</title>
        <meta name="description" content="Join KuyaPads Network - The ultimate platform for creators, entrepreneurs, and travelers. Earn KPC tokens while exploring social media, trading, booking tours, and more!" />
        <meta property="og:title" content="KuyaPads Network" />
        <meta property="og:description" content="Create • Earn • Explore — All in KuyaPads." />
        <meta property="og:image" content="https://horizons-cdn.hostinger.com/0ab4c2ed-fa43-4372-a50f-190be1a43caa/bfb567a0fadd3636d597c2c5f18977b5.png" />
      </Helmet>

      <Navigation 
        user={user}
        profile={profile}
        onLogout={handleLogout}
      />

      {user && profile && (
        <EarningsWidget 
          kpcBalance={profile.kpc_balance}
          totalEarnings={profile.total_earnings}
        />
      )}

      <main className="pt-16 flex-grow">
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<Homepage {...commonProps} />} />
            <Route path="/social" element={<SocialMedia {...commonProps} />} />
            <Route path="/wallet" element={<Wallet {...commonProps} />} />
            <Route path="/booking" element={<Booking {...commonProps} />} />
            <Route path="/trading" element={<Trading {...commonProps} />} />
            <Route path="/studio" element={<Studio {...commonProps} />} />
            <Route path="/shop" element={<Shop {...commonProps} />} />
            <Route path="/agency" element={<Agency {...commonProps} />} />
            <Route path="/cloud" element={<Cloud {...commonProps} />} />
            <Route path="/padify" element={<Padify {...commonProps} />} />
            <Route path="/kuyamind" element={<KuyaMind {...commonProps} />} />
            <Route path="/learn-to-earn" element={<LearnToEarn {...commonProps} />} />
            <Route path="/watch-to-earn" element={<WatchToEarn {...commonProps} />} />
            <Route path="/support" element={<Support {...commonProps} />} />
            <Route path="/privacy" element={<LegalPage type="privacy" />} />
            <Route path="/terms" element={<LegalPage type="terms" />} />
            <Route path="/policy" element={<LegalPage type="policy" />} />
            <Route path="/cookies" element={<LegalPage type="cookies" />} />
            <Route path="/about" element={<LegalPage type="about" />} />
            <Route path="/contact" element={<Support {...commonProps} />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AnimatePresence>
      </main>

      <Footer />
      <Toaster />
    </div>
  );
}

export default App;