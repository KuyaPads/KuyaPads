
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Home, Search, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const NotFound = () => {
  const quickLinks = [
    { label: 'Social', path: '/social' },
    { label: 'Wallet', path: '/wallet' },
    { label: 'Booking', path: '/booking' },
    { label: 'Support', path: '/support' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center text-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="inline-block bg-gradient-to-r from-yellow-400 via-blue-500 to-green-500 p-1 rounded-full mb-8">
          <div className="bg-slate-900 rounded-full px-4 py-2">
            <span className="text-white font-bold text-5xl">404</span>
          </div>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Page Not Found</h1>
        <p className="text-lg text-white/70 mb-8 max-w-lg mx-auto">
          Oops! The page you're looking for doesn't exist. It might have been moved or deleted.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <Link to="/">
            <Button className="kuyapads-button w-full sm:w-auto">
              <Home className="w-4 h-4 mr-2" />
              Go to Homepage
            </Button>
          </Link>
          <Link to="/support">
            <Button variant="outline" className="border-white/30 text-white hover:bg-white/10 w-full sm:w-auto">
              <Search className="w-4 h-4 mr-2" />
              Contact Support
            </Button>
          </Link>
        </div>

        <div>
          <p className="text-white/80 font-semibold mb-4">Here are some helpful links:</p>
          <div className="flex flex-wrap justify-center gap-4">
            {quickLinks.map(link => (
              <Link key={link.path} to={link.path} className="flex items-center space-x-2 text-blue-400 hover:text-yellow-400 transition-colors">
                <span>{link.label}</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default NotFound;
